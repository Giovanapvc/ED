#include <stdio.h>
#ifndef FAT_H
#define FAT_H


long long fatorial_iterativo(long long n);
long long fatorial_recursivo(long long n);

#endif
