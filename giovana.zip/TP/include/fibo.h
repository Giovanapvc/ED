#include <stdio.h>
#ifndef FIBO_H
#define FIBO_H

long long fibonacci_iterativo(long long n);
long long fibonacci_recursivo(long long n);

#endif